
# print(,file=args["output"])

def label_(args):
    print("hi",file=args["output"])